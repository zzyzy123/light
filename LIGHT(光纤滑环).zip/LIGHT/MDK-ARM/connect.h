#ifndef __CONNECT_H
#define __CONNECT_H
#include "main.h"
#include "usart.h"
void send_data_yuntai(void);
void send_data_encoder(void);
#endif