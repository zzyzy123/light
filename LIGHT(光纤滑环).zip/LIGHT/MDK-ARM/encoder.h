#ifndef __ENCODER_H
#define __ENCODER_H
#include "main.h"
#include "spi.h"
#define  SPI_CS_LOW1()  HAL_GPIO_WritePin(GPIOA, CS1_Pin, GPIO_PIN_RESET)
#define  SPI_CS_LOW2()  HAL_GPIO_WritePin(GPIOB, CS2_Pin, GPIO_PIN_RESET)
#define  SPI_CS_LOW3()  HAL_GPIO_WritePin(GPIOB, CS3_Pin, GPIO_PIN_RESET)
#define  SPI_CS_LOW4()  HAL_GPIO_WritePin(GPIOA, CS4_Pin, GPIO_PIN_RESET)

#define  SPI_CS_HIGH1()  HAL_GPIO_WritePin(GPIOA, CS1_Pin, GPIO_PIN_SET)
#define  SPI_CS_HIGH2()  HAL_GPIO_WritePin(GPIOB, CS2_Pin, GPIO_PIN_SET)
#define  SPI_CS_HIGH3()  HAL_GPIO_WritePin(GPIOB, CS3_Pin, GPIO_PIN_SET)
#define  SPI_CS_HIGH4()  HAL_GPIO_WritePin(GPIOA, CS4_Pin, GPIO_PIN_SET)
double AMT203_ReadData(void);
double AMT203_ReadData_2(void);
double AMT203_ReadData_3(void);
#endif

