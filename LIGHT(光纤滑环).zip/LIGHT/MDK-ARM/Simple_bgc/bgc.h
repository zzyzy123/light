#ifndef __BGC_H__
#define __BGC_H__
#include "main.h"
#include "stdio.h"
//control mode
#define SBGC_CONTROL_MODE_ANGLE       0x02  //�̶��ٶȿ���
#define SBGC_CONTROL_MODE_SPEED_ANGLE 0x03  //3 //�����ٶȿ���
#define CONTROL_FLAG_AUTO_TASK (1<<6)

//Command ID definitions
#define SBGC_CMD_CONTROL   0x43       //67  //���ƽ��ٶ�ָ��ID
#define SBGC_CMD_GET_ANGLES  0x49     //73  //��ȡ�Ƕ�ָ��ID

#define SBGC_CMD_DATA_SIZE 250       //

#define SBGC_ANGLE_FULL_TURN 16384   //�Ƕ�����ֵ

#define SBGC_DEGREE_ANGLE_SCALE ((float)SBGC_ANGLE_FULL_TURN/360.0f)//�Ƕȶ��ڶ�����ֵ
#define SBGC_DEGREE_TO_ANGLE(val) ((val)*SBGC_DEGREE_ANGLE_SCALE)//

#define SBGC_ANGLE_DEGREE_SCALE (360.0f/(float)SBGC_ANGLE_FULL_TURN)//��ֵ��Ӧ���ٽǶ�
#define SBGC_ANGLE_TO_DEGREE(val) ((val)*SBGC_ANGLE_DEGREE_SCALE)//

#define SBGC_SPEED_SCALE  (1.0f/0.1220740379f)//ÿһ����Ҫ����
#define u8 uint8_t
void crc16_calculate(uint16_t length, uint8_t *data, uint8_t crc[2]);
void BGC_Send_Date(u8* dbuf,uint16_t len);
void BGC_AngleSpeed_Msg(int16_t speedROLL,int16_t angleROLL,int16_t speedPITCH,int16_t anglePITCH,int16_t speedYAW,int16_t angleYAW,uint8_t mode_ROLL,uint8_t mode_PITCH,uint8_t mode_YAW);
void BGC_Subscribe_RealTimeData(void);
void BGC_GetRealTime_Data(void);
void BGC_GetAngle_Msg(void);
void set_data_send(uint8_t mode,uint8_t send_pv,uint8_t flag1,uint8_t flag2);
void set_angle_speed(float yaw_angle,float pitch_angle,float roll_angle,float yaw_speed,float pitch_speed,float roll_speed,int yaw_mode,int pitch_mode,int roll_mode);
typedef struct  __attribute__((packed)){
    u8 start_flag;
    u8 id;
    u8 len;
    u8 header_checksum;
    u8 mode_ROLL;
    u8 mode_PITCH;
    u8 mode_YAW;
    u8 sR1;
    u8 sR2;
    u8 aR1;
    u8 aR2;
    u8 sP1;
    u8 sP2;
    u8 aP1;
    u8 aP2;
    u8 sY1;
    u8 sY2;
    u8 aY1;
    u8 aY2;
    u8 header;
    u8 payload;
} AngleControl;//�Ƕȿ��ƽṹ��

typedef struct  __attribute__((packed)){
    u8 start_flag;
    u8 id;
    u8 len;
    u8 header_checksum;
    u8 flag1;
	  u8 flag2;
	  u8 flag3;
	  u8 flag4;
	  u8 data1;
	  u8 data2;
	  u8 data3;
	  u8 data4;
	  u8 data5;
	  u8 data6;
    u8 header;
    u8 payload;
} GetRealTime;

typedef struct  __attribute__((packed)){
    u8 start_flag;
    u8 id;
    u8 len;
    u8 header_checksum;
    u8 data1;
    u8 data2;
    u8 header;
    u8 payload;
} ReadINFO;

typedef struct  __attribute__((packed)){
    u8 start_flag;
    u8 id;
    u8 len;
    u8 header_checksum;
    u8 title;
	  u8 time1;
	  u8 time2;
	  u8 flag1;
	  u8 flag2;
	  u8 flag3;
	  u8 flag4;
	  u8 data1;
	  u8 data2;
	  u8 data3;
	  u8 data4;
	  u8 data5;
	  u8 data6;
	  u8 data7;
	  u8 data8;
	  u8 data9;
	  u8 data10;
	  u8 data11;
	  u8 data12;
	  u8 data13;
	  u8 data14;
    u8 header;
    u8 payload;
} SubscribeData;

#endif

