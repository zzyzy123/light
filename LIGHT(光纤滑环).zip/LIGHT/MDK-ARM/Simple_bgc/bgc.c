#include "bgc.h"
#include "usart.h"
uint8_t TX_BUF[30];
uint8_t RX_BUF[30];
//�������ٶ� �����Ƕ� �������ٶ� �����Ƕ� ƫ�����ٶ� ƫ���Ƕ����� 0--������ 1--�ٶȿ��� 2--�Ƕȿ��� 3--�ٶȽǶȿ���
void BGC_AngleSpeed_Msg(int16_t speedROLL,int16_t angleROLL,int16_t speedPITCH,int16_t anglePITCH,int16_t speedYAW,int16_t angleYAW,uint8_t mode_ROLL,uint8_t mode_PITCH,uint8_t mode_YAW) 
{
    uint8_t crc[2] = {0};
    uint8_t data[18] = {0};
    AngleControl *Angle_Control=(AngleControl *)TX_BUF;
    Angle_Control->start_flag = 0x24;//��ʼλ 0x24
    Angle_Control->id = SBGC_CMD_CONTROL;//���ٶ���Ƕ�����ָ��
    Angle_Control->len = 0x0F;//����ָ���,8λ
    Angle_Control->header_checksum = SBGC_CMD_CONTROL+0x0F;//ͷ����־λУ���

    Angle_Control->mode_ROLL = mode_ROLL;//- use as a camera attitude
    Angle_Control->mode_PITCH = mode_PITCH;//
    Angle_Control->mode_YAW = mode_YAW;//

    Angle_Control->sR1 = speedROLL;
    Angle_Control->sR2 = speedROLL>>8;
    Angle_Control->aR1 = angleROLL;
    Angle_Control->aR2 = angleROLL>>8;

    Angle_Control->sP1 = speedPITCH;
    Angle_Control->sP2 = speedPITCH>>8;
    Angle_Control->aP1 = anglePITCH;
    Angle_Control->aP2 = anglePITCH>>8;

    Angle_Control->sY1 = speedYAW;
    Angle_Control->sY2 = speedYAW>>8;
    Angle_Control->aY1 = angleYAW;
    Angle_Control->aY2 = angleYAW>>8;

    data[0] = SBGC_CMD_CONTROL;
    data[1] = 0x0F;
    data[2] = SBGC_CMD_CONTROL+0x0F;
    data[3] = mode_ROLL;
    data[4] = mode_PITCH;
    data[5] = mode_YAW;
    data[6] = Angle_Control->sR1;
    data[7] = Angle_Control->sR2;
    data[8] = Angle_Control->aR1;
    data[9] = Angle_Control->aR2;
    data[10] = Angle_Control->sP1;
    data[11] = Angle_Control->sP2;
    data[12] = Angle_Control->aP1;
    data[13] = Angle_Control->aP2;
    data[14] = Angle_Control->sY1;
    data[15] = Angle_Control->sY2;
    data[16] = Angle_Control->aY1;
    data[17] = Angle_Control->aY2;
    crc16_calculate(sizeof(data), data, crc);//CRCУ���

    Angle_Control->header = crc[0];
    Angle_Control->payload = crc[1];

    BGC_Send_Date((u8*)Angle_Control,21);
}
//��ȡ�Ƕ���Ϣ 73 02 4B
void BGC_GetAngle_Msg(void)
{
    uint8_t crc[2] = {0};
    uint8_t data[5] = {0};
    ReadINFO *Read_INFO=(ReadINFO *)RX_BUF;
    Read_INFO->start_flag = 0x24;
    Read_INFO->id = 0x49;//��ȡ�Ƕ�����ָ��
    Read_INFO->len = 0x02;
    Read_INFO->header_checksum = 0x4B;
    Read_INFO->data1 = 0;
    Read_INFO->data2 = 0;

    data[0]=0x49;
    data[1]=0x02;
    data[2]=0x4B;
    data[3]=0;
    data[4]=0;
    crc16_calculate(sizeof(data), data, crc);
    Read_INFO->header = crc[0];
    Read_INFO->payload = crc[1];

    BGC_Send_Date((u8*)Read_INFO,8);
}
//��ȡʵʱ���� 88 0A 62 08
void BGC_GetRealTime_Data(void)
{
    uint8_t crc[2] = {0};
    uint8_t data[13] = {0};
    GetRealTime *Get_Real_Time=(GetRealTime *)TX_BUF;
    Get_Real_Time->start_flag = 0x24;
    Get_Real_Time->id = 0x58;//��ȡʵʱ����ָ��
    Get_Real_Time->len = 0x0A;
    Get_Real_Time->header_checksum = 0x62;
    Get_Real_Time->flag2 = 0x08;//����������

    data[0]=0x58;
    data[1]=0x0A;
    data[2]=0x62;
    data[3]=0x00;
    data[4]=0x08;
    crc16_calculate(sizeof(data), data, crc);
    Get_Real_Time->header = crc[0];
    Get_Real_Time->payload = crc[1];

    BGC_Send_Date((u8*)Get_Real_Time,16);
}
//����ʵʱ����ָ�� 85 15 6A 58 14 01 08
void BGC_Subscribe_RealTimeData(void)
{
    uint8_t crc[2] = {0};
    uint8_t data[24] = {0};
    SubscribeData *Subscribe_Data=(SubscribeData *)TX_BUF;
    Subscribe_Data->start_flag = 0x24;
    Subscribe_Data->id = 0x55;//����ʵʱ���ݴ�����ָ��
    Subscribe_Data->len = 0x15;
    Subscribe_Data->header_checksum = 0x6A;
    Subscribe_Data->title = 0x58;//�������� �Զ����ʽ
    Subscribe_Data->time1 = 0x14;//���ݴ���Ƶ�� 50HZ
    Subscribe_Data->time2 = 0x00;//С����λ
    Subscribe_Data->flag1 = 0x03;//���Ĳ���IMU
    Subscribe_Data->flag2 = 0x08;//IMU_ANGLES_RAD����

    data[0]=0x55;
    data[1]=0x15;
    data[2]=0x6A;
    data[3]=0x58;
    data[4]=0x14;
    data[6]=0x03;
    data[7]=0x08;

    crc16_calculate(sizeof(data), data, crc);
    Subscribe_Data->header = crc[0];
    Subscribe_Data->payload = crc[1];

    BGC_Send_Date((u8*)Subscribe_Data,27);
}
void set_data_send(uint8_t mode,uint8_t send_pv,uint8_t flag1,uint8_t flag2)
{
    uint8_t crc[2] = {0};
    uint8_t data[24] = {0};
    SubscribeData *Subscribe_Data=(SubscribeData *)TX_BUF;

    Subscribe_Data->start_flag = 0x24;
    Subscribe_Data->id = 0x55;//����ʵʱ���ݴ�����ָ��
    Subscribe_Data->len = 0x15;
    Subscribe_Data->header_checksum = Subscribe_Data->id+Subscribe_Data->len;
    if(mode==0x00)Subscribe_Data->title = 0x58;//�������� �Զ����ʽ
    else if(mode==0x01)Subscribe_Data->title = 0x19;
    else if(mode==0x02)Subscribe_Data->title = 0x17;
    Subscribe_Data->time1 =send_pv;//���ݴ���Ƶ�� 50HZ
    Subscribe_Data->time2 = 0x00;//С����λ
    Subscribe_Data->flag1 = flag1;
    Subscribe_Data->flag2 = flag2;//IMU_ANGLES_RAD����
    Subscribe_Data->flag3=0;Subscribe_Data->flag4=0;

    data[0]=Subscribe_Data->id;
    data[1]=Subscribe_Data->len;
    data[2]= Subscribe_Data->header_checksum;
    data[3]=Subscribe_Data->title;
    data[4]= Subscribe_Data->time1;
    data[5]=0x00;
    data[6]=Subscribe_Data->flag1;
    data[7]=Subscribe_Data->flag2;

    crc16_calculate(sizeof(data), data, crc);
    Subscribe_Data->header = crc[0];
    Subscribe_Data->payload = crc[1];

		BGC_Send_Date((u8*)Subscribe_Data,27);
}
void set_angle_speed(float yaw_angle,float pitch_angle,float roll_angle,float yaw_speed,float pitch_speed,float roll_speed,int yaw_mode,int pitch_mode,int roll_mode)
{
    uint8_t crc[2] = {0};
    uint8_t data[18] = {0};
    AngleControl *Angle_Control=(AngleControl *)TX_BUF;

    Angle_Control->start_flag=0x24;
    Angle_Control->id=0x43;
    Angle_Control->len=0X0F;
    Angle_Control->header_checksum=(Angle_Control->id)+(Angle_Control->len);
    Angle_Control->mode_YAW=yaw_mode;
    Angle_Control->mode_PITCH=pitch_mode;
    Angle_Control->mode_ROLL=roll_mode;

    Angle_Control->sP1=(int16_t)(pitch_speed/0.1220740397f);
    Angle_Control->sP2=(int16_t)(pitch_speed/0.1220740397f)>>8;

    Angle_Control->sY1=(int16_t)(yaw_speed/0.1220740397f);
    Angle_Control->sY2=(int16_t)(yaw_speed/0.1220740397f)>>8;

    Angle_Control->sR1=(int16_t)(roll_speed/0.1220740397f);
    Angle_Control->sR2=(int16_t)(roll_speed/0.1220740397f)>>8;

    Angle_Control->aP1=(int16_t)(pitch_angle*45.51111111111111f);
    Angle_Control->aP2=(int16_t)(pitch_angle*45.51111111111111f)>>8;

    Angle_Control->aY1=(int16_t)(yaw_angle*45.51111111111111f);
    Angle_Control->aY2=(int16_t)(yaw_angle*45.51111111111111f)>>8;

    Angle_Control->aR1=(int16_t)(roll_angle*45.51111111111111f);
    Angle_Control->aR2=(int16_t)(roll_angle*45.51111111111111f)>>8;

    data[0] = Angle_Control->id;
    data[1] = Angle_Control->len;
    data[2] = Angle_Control->header_checksum;
    data[3] = Angle_Control->mode_ROLL;
    data[4] = Angle_Control->mode_PITCH;
    data[5] = Angle_Control->mode_YAW;
    data[6] = Angle_Control->sR1;
    data[7] = Angle_Control->sR2;
    data[8] = Angle_Control->aR1;
    data[9] = Angle_Control->aR2;
    data[10] = Angle_Control->sP1;
    data[11] = Angle_Control->sP2;
    data[12] = Angle_Control->aP1;
    data[13] = Angle_Control->aP2;
    data[14] = Angle_Control->sY1;
    data[15] = Angle_Control->sY2;
    data[16] = Angle_Control->aY1;
    data[17] = Angle_Control->aY2;

    crc16_calculate(sizeof(data), data, crc);//CRCУ���

    Angle_Control->header=crc[0];
    Angle_Control->payload=crc[1];

		BGC_Send_Date((u8*)Angle_Control,21);
}
//����crcУ��
void crc16_update(uint16_t length, uint8_t *data, uint8_t crc[2])
{
    uint16_t counter;
    uint16_t polynom = 0x8005;
    uint16_t crc_register = (uint16_t)crc[0] | ((uint16_t)crc[1] << 8);
    uint8_t shift_register;
    uint8_t data_bit, crc_bit;
    for (counter = 0; counter < length; counter++)
    {
        for (shift_register = 0x01; shift_register > 0x00; shift_register <<= 1)
        {
            data_bit = (data[counter] & shift_register) ? 1 : 0;
            crc_bit = crc_register >> 15;
            crc_register <<= 1;
            if (data_bit != crc_bit) crc_register ^= polynom;
        }
    }
    crc[0] = crc_register;
    crc[1] = (crc_register >> 8);
}

//��crcУ���
void crc16_calculate(uint16_t length, uint8_t *data, uint8_t crc[2])
{
    crc[0] = 0;
    crc[1] = 0;
    crc16_update(length, data, crc);
}
//�������ݺ���
void BGC_Send_Date(u8* dbuf,uint16_t len)
{
    HAL_UART_Transmit(&huart2,(uint8_t *)dbuf,len,0xff);
} 