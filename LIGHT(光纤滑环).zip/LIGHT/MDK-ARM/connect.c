#include "connect.h"
extern float encoder_yaw,encoder_roll,encoder_pitch;
extern double encoder_1;
extern double encoder_2;
extern double encoder_3;
void send_data_yuntai()
{
	uint8_t buf[11];
	buf[0]=0xFF;
	buf[1]=0xAA;
	buf[2]=(int)(encoder_yaw*10)/256;
	buf[3]=(int)(encoder_yaw*10)%256;
	buf[4]=(int)(encoder_pitch*10)/256;
	buf[5]=(int)(encoder_pitch*10)%256;
	buf[6]=(int)(encoder_roll*10)/256;
	buf[7]=(int)(encoder_roll*10)%256;
	if(encoder_yaw<0)buf[8]=0;
	else buf[8]=1;
	
	if(encoder_pitch<0)buf[9]=0;
	else buf[9]=1;
	
	if(encoder_roll<0)buf[10]=0;
	else buf[10]=1;
	
	HAL_UART_Transmit(&huart1,buf,11,0xff);
}

void send_data_encoder()
{
	uint8_t buf[8];
	buf[0]=0xFF;
	buf[1]=0xBB;
	buf[2]=(int)(encoder_1*10)/256;
	buf[3]=(int)(encoder_1*10)%256;
	buf[4]=(int)(encoder_2*10)/256;
	buf[5]=(int)(encoder_2*10)%256;
	buf[6]=(int)(encoder_3*10)/256;
	buf[7]=(int)(encoder_3*10)%256;
	
	HAL_UART_Transmit(&huart1,buf,8,0xff);
}