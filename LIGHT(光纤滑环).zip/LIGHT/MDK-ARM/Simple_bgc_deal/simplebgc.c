#include "simplebgc.h"
#include "connect.h"
//��ʼ���豸
char flag=0;
void init_device(void)
{
	set_data_send(0x00,0x20,0x09,0x00);
}
//�������ݽ����ź�����ȡ
//extern void simplebgc_Semaphore(void);
extern uint8_t rx_buffer_2[100];  //�������ݻ�������

//������̨����
float yaw,roll,pitch;
float encoder_yaw,encoder_roll,encoder_pitch;
void deal_simplebgc_data(void)
{
//		pitch=(int16_t)((rx_buffer[9]<<8)+rx_buffer[8])*0.02197265625f;
//		roll  =(int16_t)((rx_buffer[7]<<8)+rx_buffer[6])*0.02197265625f;
//		yaw  =(int16_t)((rx_buffer[11]<<8)+rx_buffer[10])*0.02197265625f;
//		0.01730130413
		encoder_pitch=(int16_t)((rx_buffer_2[15]<<8)+rx_buffer_2[14])*0.02197265625f;
		encoder_roll  =(int16_t)((rx_buffer_2[13]<<8)+rx_buffer_2[12])*0.02197265625f;
		encoder_yaw  =(int16_t)((rx_buffer_2[17]<<8)+rx_buffer_2[16])*0.02197265625f;
}
//��̨����
float current_encoder=0.0f;
float yaw_out=0.0f;

float cur_yaw=0.0f,cur_pitch=0.0f,cur_roll=0.0f;
float cur_yaw_speed=0.0f,cur_pitch_speed=0.0f,cur_roll_speed=0.0f;
int cur_yaw_mode=0,cur_pitch_mode=0,cur_roll_mode=0;

char start_set_position_flag=0;
char set_position_flag=0;
float PID_BUF[12]={0};
//��̨����
void control_simplebgc_angle_speed_mode(float yaw_angle,float pitch_angle,float roll_angle,float yaw_speed,float pitch_speed,float roll_speed,int yaw_mode,int pitch_mode,int roll_mode)
{
//	if(start_set_position_flag==10)
//	{	
		cur_yaw=yaw_angle;cur_pitch=pitch_angle;cur_roll=roll_angle;
		cur_yaw_speed=yaw_speed;cur_pitch_speed=pitch_speed;cur_roll_speed=roll_speed;
		cur_yaw_mode=yaw_mode;cur_pitch_mode=pitch_mode;cur_roll_mode=roll_mode;
		
		set_angle_speed(cur_yaw+yaw_out,cur_pitch,cur_roll,cur_yaw_speed,cur_pitch_speed,cur_roll_speed,cur_yaw_mode,cur_pitch_mode,cur_roll_mode);
		set_position_flag=0;
//	}
}				