#ifndef __SIMPLEBGC_H
#define __SIMPLEBGC_H	
#include "bgc.h"
#include "main.h"
#include <stdio.h>	
#include <string.h> 
void init_device(void);
void get_usart_data(void);
void deal_simplebgc_data(void);
void keep_zero(void);
void control_simplebgc_angle_speed_mode(float yaw_angle,float pitch_angle,float roll_angle,float yaw_speed,float pitch_speed,float roll_speed,int yaw_mode,int pitch_mode,int roll_mode);
#endif
