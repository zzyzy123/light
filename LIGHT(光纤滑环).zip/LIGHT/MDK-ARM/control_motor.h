#ifndef __CONTROL_MOTOR_H
#define __CONTROL_MOTOR_H
#include "main.h"
#include "tim.h"
#include "dma.h"
void control_motor(float setpoint_1,float setpoint_2,float setpoint_3,float setpoint_4,float setpoint_5,float setpoint_6);
#endif