#include "control_motor.h"
#include "math.h"
double PID_feedback_1(double difference,double Kp,double Ki,double Kd)
{
	//pid����
	static double Pitem = 0,Iitem = 0,Ditem = 0,control = 0;
	// ����ʽPID�� ��˴κ�ǰ����״̬�й�
	static double last_error=0, last_last_error=0;
	Pitem = Kp * difference;
	Iitem = Ki * (difference + last_error + last_last_error);
	Ditem = Kd * (difference - last_error);
	
	control = Pitem + Iitem + Ditem;
	
	last_last_error = last_error;
	last_error = difference;
	if(control>1000)control=1000;
	else if(control<-1000)control=-1000;
	
	return control;
}

double PID_feedback_2(double difference,double Kp,double Ki,double Kd)
{
	//pid����
	static double Pitem = 0,Iitem = 0,Ditem = 0,control = 0;
	// ����ʽPID�� ��˴κ�ǰ����״̬�й�
	static double last_error=0, last_last_error=0;
	Pitem = Kp * difference;
	Iitem = Ki * (difference + last_error + last_last_error);
	Ditem = Kd * (difference - last_error);
	
	control = Pitem + Iitem + Ditem;
	
	last_last_error = last_error;
	last_error = difference;
	if(control>1000)control=1000;
	else if(control<-1000)control=-1000;
	
	return control;
}

double PID_feedback_3(double difference,double Kp,double Ki,double Kd)
{
	//pid����
	static double Pitem = 0,Iitem = 0,Ditem = 0,control = 0;
	// ����ʽPID�� ��˴κ�ǰ����״̬�й�
	static double last_error=0, last_last_error=0;
	Pitem = Kp * difference;
	Iitem = Ki * (difference + last_error + last_last_error);
	Ditem = Kd * (difference - last_error);
	
	control = Pitem + Iitem + Ditem;
	
	last_last_error = last_error;
	last_error = difference;
	if(control>1000)control=1000;
	else if(control<-1000)control=-1000;
	
	return control;
}

double PID_feedback_4(double difference,double Kp,double Ki,double Kd)
{
	//pid����
	static double Pitem = 0,Iitem = 0,Ditem = 0,control = 0;
	// ����ʽPID�� ��˴κ�ǰ����״̬�й�
	static double last_error=0, last_last_error=0;
	Pitem = Kp * difference;
	Iitem = Ki * (difference + last_error + last_last_error);
	Ditem = Kd * (difference - last_error);
	
	control = Pitem + Iitem + Ditem;
	
	last_last_error = last_error;
	last_error = difference;
	if(control>2)control=2;
	else if(control<-2)control=-2;
	
	return control;
}

double PID_feedback_5(double difference,double Kp,double Ki,double Kd)
{
	//pid����
	static double Pitem = 0,Iitem = 0,Ditem = 0,control = 0;
	// ����ʽPID�� ��˴κ�ǰ����״̬�й�
	static double last_error=0, last_last_error=0;
	Pitem = Kp * difference;
	Iitem = Ki * (difference + last_error + last_last_error);
	Ditem = Kd * (difference - last_error);
	
	control = Pitem + Iitem + Ditem;
	
	last_last_error = last_error;
	last_error = difference;
	if(control>2)control=2;
	else if(control<-2)control=-2;
	
	return control;
}

double PID_feedback_6(double difference,double Kp,double Ki,double Kd)
{
	//pid����
	static double Pitem = 0,Iitem = 0,Ditem = 0,control = 0;
	// ����ʽPID�� ��˴κ�ǰ����״̬�й�
	static double last_error=0, last_last_error=0;
	Pitem = Kp * difference;
	Iitem = Ki * (difference + last_error + last_last_error);
	Ditem = Kd * (difference - last_error);
	
	control = Pitem + Iitem + Ditem;
	
	last_last_error = last_error;
	last_error = difference;
	if(control>2)control=2;
	else if(control<-2)control=-2;
	
	return control;
}
uint16_t send_buf1[4096];
uint16_t send_buf2[4096];
uint16_t send_buf3[4096];

void motor1_movestep(uint16_t step_num)
{
    int i = 0;

    for(i = 0; i < step_num+1; ++i)
    {
        if(i != step_num)
        {
            send_buf1[i] = 1;
        }
        else
        {
            send_buf1[i] = 0;
        }
    }
		HAL_TIM_PWM_Start_DMA(&htim3, TIM_CHANNEL_4,(uint32_t*)send_buf1,step_num+1);
}

void motor2_movestep(uint16_t step_num)
{
    int i = 0;

    for(i = 0; i < step_num+1; ++i)
    {
        if(i != step_num)
        {
            send_buf2[i] = 1;
        }
        else
        {
            send_buf2[i] = 0;
        }
    }
		HAL_TIM_PWM_Start_DMA(&htim2, TIM_CHANNEL_2,(uint32_t*)send_buf2,step_num+1);
}

void motor3_movestep(uint16_t step_num)
{
    int i = 0;

    for(i = 0; i < step_num+1; ++i)
    {
        if(i != step_num)
        {
            send_buf3[i] = 1;
        }
        else
        {
            send_buf3[i] = 0;
        }
    }
		HAL_TIM_PWM_Start_DMA(&htim4, TIM_CHANNEL_2,(uint32_t*)send_buf3,step_num+1);
}
extern double encoder_1;
extern double encoder_2;
extern double encoder_3;
extern float encoder_yaw,encoder_roll,encoder_pitch;
extern void control_simplebgc_angle_speed_mode(float yaw_angle,float pitch_angle,float roll_angle,float yaw_speed,float pitch_speed,float roll_speed,int yaw_mode,int pitch_mode,int roll_mode);
void control_motor(float setpoint_1,float setpoint_2,float setpoint_3,float setpoint_4,float setpoint_5,float setpoint_6)
{
	int16_t control_bmq1 = 0,control_bmq2 = 0,control_bmq3 = 0;
	float control_bmq4 = 0,control_bmq5 = 0,control_bmq6 = 0;
	float error_1 =0.0,error_2=0.0,error_3=0.0,error_4,error_5,error_6;
	
	if(setpoint_1<=0.5)setpoint_1=0.5;
	else if(setpoint_1>=359.5)setpoint_1=359.5;
	if(setpoint_2<=0.5)setpoint_2=0.5;
	else if(setpoint_2>=359.5)setpoint_2=359.5;
	if(setpoint_3<=0.5)setpoint_3=0.5;
	else if(setpoint_3>=359.5)setpoint_3=359.5;
	
	error_1=encoder_1-setpoint_1;
	error_2=encoder_2-setpoint_2;
	error_3=encoder_3-setpoint_3;
	error_4=encoder_yaw-setpoint_4;
	error_5=encoder_pitch-setpoint_5;
	error_6=encoder_roll-setpoint_6;
	//motor
//	if(encoder_1<0.5&&setpoint_1<=1)error_1=0;
//	if(encoder_2<0.5&&setpoint_2<=1)error_2=0;
//	if(encoder_3<0.5&&setpoint_3<=1)error_3=0;
//	
//	if(encoder_1>359.5&&setpoint_1>=359)error_1=0;
//	if(encoder_2>359.5&&setpoint_2>=359)error_2=0;
//	if(encoder_3>359.5&&setpoint_3>=359)error_3=0;
	
	control_bmq1+=PID_feedback_1(error_1,3.0,0.1,0);
	control_bmq2+=PID_feedback_2(error_2,5.0,0.2,0);
	control_bmq3+=PID_feedback_3(error_3,5.0,0.2,0);
	
	if(control_bmq2>=0){HAL_GPIO_WritePin(GPIOF, GPIO_PIN_3, GPIO_PIN_SET);motor2_movestep(control_bmq2);}
	else if(control_bmq2<0){HAL_GPIO_WritePin(GPIOF, GPIO_PIN_3, GPIO_PIN_RESET);motor2_movestep(-control_bmq2);}
	
	if(control_bmq1>=0){HAL_GPIO_WritePin(GPIOF, GPIO_PIN_1, GPIO_PIN_SET);motor1_movestep(control_bmq1);}
	else if(control_bmq1<0){HAL_GPIO_WritePin(GPIOF, GPIO_PIN_1, GPIO_PIN_RESET);motor1_movestep(-control_bmq1);}
	
	if(control_bmq3>=0){HAL_GPIO_WritePin(GPIOF, GPIO_PIN_5, GPIO_PIN_SET);motor3_movestep(control_bmq3);}
	else if(control_bmq3<0){HAL_GPIO_WritePin(GPIOF, GPIO_PIN_5, GPIO_PIN_RESET);motor3_movestep(-control_bmq3);}
	//yuntai
	if(encoder_yaw<-179&&setpoint_4<=-170)error_4=0;
	if(encoder_pitch<-179&&setpoint_5<=-170)error_5=0;
	if(encoder_roll<-179&&setpoint_6<=-170)error_6=0;
	
	if(encoder_yaw>179&&setpoint_4>=170)error_4=0;
	if(encoder_pitch>179&&setpoint_5>=170)error_5=0;
	if(encoder_roll>179&&setpoint_6>=170)error_6=0;
	
	control_bmq4+=PID_feedback_4(-error_4,2.0,0.05,0);
	control_bmq5+=PID_feedback_5(-error_5,1.0,0.05,0);
  control_bmq6+=PID_feedback_6(-error_6,1.0,0.05,0);
	
	control_simplebgc_angle_speed_mode(0,0,0,control_bmq4,control_bmq5,control_bmq6,0x01,0x01,0x01);
}
