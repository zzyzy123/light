from PyQt5 import QtCore, QtGui, QtWidgets
# import cv2
# from paddleocr import PaddleOCR, draw_ocr
# import pyautogui
import win32gui,win32con
import time
import numpy
import array
import os
import threading
import sys
from PyQt5.QtSerialPort import QSerialPort, QSerialPortInfo
from PyQt5.QtCore import QIODevice,QBasicTimer,QTimer,QUrl,QByteArray
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QMainWindow,QApplication,QWidget, QPushButton,QLabel
import struct
import binascii
from datetime import datetime
from ctypes import cdll,c_long, c_ulong, c_uint32,byref,create_string_buffer,c_bool,c_char_p,c_int,c_int16,c_double, sizeof, c_voidp
from TLPMX import TLPMX
import time

from TLPMX import TLPM_DEFAULT_CHANNEL
import Ui_light_ui,sys

class myDialog(Ui_light_ui.Ui_Form):
    def __init__(self,Dialog):
        super().setupUi(Dialog)
        self.refresh_serial.clicked.connect(self.refresh_serial_fuc)
        self.serial_1_open.clicked.connect(self.serial_1_open_fuc)
        self.serial_2_open.clicked.connect(self.serial_2_open_fuc)
        self.scan_btn.clicked.connect(self.scan_start_stop)
        self.set_serial_1_pos.clicked.connect(self.set_serial_1_pos_fuc)
        self.set_serial_2_pos.clicked.connect(self.set_serial_2_pos_fuc)
        self.serial_1 = QSerialPort()
        self.serial_2 = QSerialPort()
        self.portlist = QSerialPortInfo.availablePorts()
        self.timer = QTimer()      
        self.db_time = QTimer()   
        self.scan_time = QTimer()  
        self.timer.timeout.connect(self.refresh_ui)
        self.db_time.timeout.connect(self.db_read_fuc)
        self.scan_time.timeout.connect(self.scan_fuc)
        
        self.serial_1_yuntai_yaw = 0
        self.serial_1_yuntai_pitch = 0
        self.serial_1_yuntai_roll = 0
        self.serial_1_encoder_1 = 0
        self.serial_1_encoder_2 = 0
        self.serial_1_encoder_3 = 0

        self.serial_2_yuntai_yaw = 0
        self.serial_2_yuntai_pitch = 0
        self.serial_2_yuntai_roll = 0
        self.serial_2_encoder_1 = 0
        self.serial_2_encoder_2 = 0
        self.serial_2_encoder_3 = 0

        self.current_serial_1_yuntai_yaw = 0
        self.current_serial_1_yuntai_pitch = 0
        self.current_serial_1_yuntai_roll = 0
        self.current_serial_1_encoder_1 = 0
        self.current_serial_1_encoder_2 = 0
        self.current_serial_1_encoder_3 = 0

        self.current_serial_2_yuntai_yaw = 0
        self.current_serial_2_yuntai_pitch = 0
        self.current_serial_2_yuntai_roll = 0
        self.current_serial_2_encoder_1 = 0
        self.current_serial_2_encoder_2 = 0
        self.current_serial_2_encoder_3 = 0

        self.tlPM = TLPMX()
        self.deviceCount = c_uint32()
        # print(str(self.deviceCount))
        # if str(self.deviceCount) != str(c_ulong(0)):
        self.tlPM.findRsrc(byref(self.deviceCount))

        print("Number of found devices: " + str(self.deviceCount.value))
        print("")

        self.resourceName = create_string_buffer(1024)

        for i in range(0, self.deviceCount.value):
            self.tlPM.getRsrcName(c_int(i), self.resourceName)
            print("Resource name of device", i, ":", c_char_p(self.resourceName.raw).value)
        print("")
        self.tlPM.close()

        # Connect to last device.
        self.tlPM = TLPMX()
        self.tlPM.open(self.resourceName, c_bool(True), c_bool(True))

        self.message = create_string_buffer(1024)
        self.tlPM.getCalibrationMsg(self.message,TLPM_DEFAULT_CHANNEL)
        print("Connected to device", i)
        print("Last calibration date: ",c_char_p(self.message.raw).value)
        print("")

        time.sleep(2)

        # Set wavelength in nm.
        self.wavelength = c_double(532.5)
        self.tlPM.setWavelength(self.wavelength,TLPM_DEFAULT_CHANNEL)

        # Enable auto-range mode.
        # 0 -> auto-range disabled
        # 1 -> auto-range enabled
        self.tlPM.setPowerAutoRange(c_int16(1),TLPM_DEFAULT_CHANNEL)

        # Set power unit to Watt.
        # 0 -> Watt
        # 1 -> dBm
        self.tlPM.setPowerUnit(c_int16(1),TLPM_DEFAULT_CHANNEL)

        # Take power measurements and save results to arrays.
        self.power_measurements = []
        self.current_power_measurements = -100
        self.times = []
        self.count = 0
        self.max_db = -100

        self.timer.start(100)
        self.db_time.start(10)

    def refresh_serial_fuc(self):
        self.portlist = QSerialPortInfo.availablePorts()
        self.serial_1_list.clear()
        self.serial_2_list.clear()
        # print(portlist)
        for x in self.portlist:
            self.serial_1_list.addItem(x.portName())
            self.serial_2_list.addItem(x.portName())

    def scan_start_stop(self):
        if self.scan_btn.text() == "开始扫描":
            self.scan_btn.setText("结束扫描")
            self.scan_time.start(100)
        elif self.scan_btn.text() == "结束扫描":
            self.scan_btn.setText("开始扫描")
            self.scan_time.stop()

    def serial_1_open_fuc(self):
        port_name = self.serial_1_list.currentText()
        baud_rate = 115200

        self.serial_1.setPortName(port_name)
        self.serial_1.setBaudRate(baud_rate)
        self.serial_1.setDataBits(QSerialPort.Data8)
        self.serial_1.setParity(QSerialPort.NoParity)
        self.serial_1.setStopBits(QSerialPort.OneStop)
        self.serial_1.setFlowControl(QSerialPort.NoFlowControl)

        if not self.serial_1.isOpen():
            if self.serial_1.open(QIODevice.ReadWrite):
                self.serial_1.readyRead.connect(self.on_serial_1_read)
                self.serial_1_open.setText("关闭串口")
                print(port_name)
        else :
            self.serial_1.close()
            self.serial_1_open.setText("打开串口")
    
    def serial_2_open_fuc(self):
        port_name = self.serial_2_list.currentText()
        baud_rate = 115200

        self.serial_2.setPortName(port_name)
        self.serial_2.setBaudRate(baud_rate)
        self.serial_2.setDataBits(QSerialPort.Data8)
        self.serial_2.setParity(QSerialPort.NoParity)
        self.serial_2.setStopBits(QSerialPort.OneStop)
        self.serial_2.setFlowControl(QSerialPort.NoFlowControl)

        if not self.serial_2.isOpen():
            if self.serial_2.open(QIODevice.ReadWrite):
                self.serial_2.readyRead.connect(self.on_serial_2_read)
                self.serial_2_open.setText("关闭串口")
                print(port_name)
        else :
            self.serial_2.close()
            self.serial_2_open.setText("打开串口")

    def on_serial_1_read(self):
        bytes_to_read = self.serial_1.read(1024)
        hex_data=bytes_to_read.hex()
        hex_data=' '.join([hex_data[i:i+2] for i in range(0,len(hex_data),2)])
        data = QByteArray.fromHex(hex_data.encode())
#        print(data.length())
        if data.length() == 19:
            if ord(data[0]) == int('FF',16) and ord(data[1])== int('AA',16) and ord(data[11]) == int('FF',16) and ord(data[12])== int('BB',16):
                if ord(data[8])==0:
                    self.serial_1_yuntai_yaw = -(ord(data[2])*256+ord(data[3]))/10
                else:
                    self.serial_1_yuntai_yaw = (ord(data[2])*256+ord(data[3]))/10

                if ord(data[9])==0:    
                    self.serial_1_yuntai_pitch = -(ord(data[4])*256+ord(data[5]))/10
                else:
                    self.serial_1_yuntai_pitch = (ord(data[4])*256+ord(data[5]))/10
            
                if ord(data[10])==0:
                    self.serial_1_yuntai_roll = -(ord(data[6])*256+ord(data[7]))/10
                else:
                    self.serial_1_yuntai_roll = (ord(data[6])*256+ord(data[7]))/10  
                self.serial_1_encoder_1 = (ord(data[13])*256+ord(data[14]))/10
                self.serial_1_encoder_2 = (ord(data[15])*256+ord(data[16]))/10
                self.serial_1_encoder_3 = (ord(data[17])*256+ord(data[18]))/10
        else:
            pass

    def on_serial_2_read(self):
        bytes_to_read = self.serial_2.read(1024)
        hex_data=bytes_to_read.hex()
        hex_data=' '.join([hex_data[i:i+2] for i in range(0,len(hex_data),2)])
        data = QByteArray.fromHex(hex_data.encode())
#        print(data.length())
        if data.length() == 19:
            if ord(data[0]) == int('FF',16) and ord(data[1])== int('AA',16) and ord(data[11]) == int('FF',16) and ord(data[12])== int('BB',16):
                if ord(data[8])==0:
                    self.serial_2_yuntai_yaw = -(ord(data[2])*256+ord(data[3]))/10
                else:
                    self.serial_2_yuntai_yaw = (ord(data[2])*256+ord(data[3]))/10

                if ord(data[9])==0:    
                    self.serial_2_yuntai_pitch = -(ord(data[4])*256+ord(data[5]))/10
                else:
                    self.serial_2_yuntai_pitch = (ord(data[4])*256+ord(data[5]))/10
            
                if ord(data[10])==0:
                    self.serial_2_yuntai_roll = -(ord(data[6])*256+ord(data[7]))/10
                else:
                    self.serial_2_yuntai_roll = (ord(data[6])*256+ord(data[7]))/10  
                self.serial_2_encoder_1 = (ord(data[13])*256+ord(data[14]))/10
                self.serial_2_encoder_2 = (ord(data[15])*256+ord(data[16]))/10
                self.serial_2_encoder_3 = (ord(data[17])*256+ord(data[18]))/10
        else:
            pass

    def db_read_fuc(self):
        # pass
        power =  c_double()
        self.tlPM.measPower(byref(power),TLPM_DEFAULT_CHANNEL)

        self.power_measurements.append(power.value)
        self.times.append(datetime.now())
        if self.count!=0:
        #     # self.label.setText(str(self.power_measurements[self.count])+" dB")
            self.current_power_measurements = self.power_measurements[self.count]
            # if self.current_power_measurements > self.max_db:
            #     data = [self.current_power_measurements,self.serial_1_yuntai_yaw,self.serial_1_yuntai_pitch,self.serial_1_yuntai_roll,self.serial_1_encoder_1,self.serial_1_encoder_2,self.serial_1_encoder_3,self.serial_2_encoder_1,self.serial_2_encoder_2,self.serial_2_encoder_3]
            #     self.data_0 = numpy.array([data])
            #     if os.path.exists("data.txt"):
            #             with open('data.txt','a')as f:
            #                 numpy.savetxt(f, self.data_0, fmt='%s')  
            #     else:
            #             numpy.savetxt("data.txt",self.data_0,fmt='%s')
            #     self.max_db = self.current_power_measurements
        self.count =self.count + 1

    def data_send_serial_1(self,move_yaw,move_pitch,move_roll,move_encoder_1,move_encoder_2,move_encoder_3):
        buffer=struct.pack(">BBhhhhhh",238,204,int(move_yaw*10),int(move_pitch*10),int(move_roll*10),int(move_encoder_1*10),int(move_encoder_2*10),int(move_encoder_3*10))
        self.serial_1.write(buffer)
    
    def data_send_serial_2(self,move_yaw,move_pitch,move_roll,move_encoder_1,move_encoder_2,move_encoder_3):
        buffer=struct.pack(">BBhhhhhh",238,204,int(move_yaw*10),int(move_pitch*10),int(move_roll*10),int(move_encoder_1*10),int(move_encoder_2*10),int(move_encoder_3*10))
        self.serial_2.write(buffer)

    def set_serial_1_pos_fuc(self):
        self.data_send_serial_1(self.serial_1_yaw.value(),self.serial_1_pitch.value(),self.serial_1_roll.value(),self.serial_1_encoder_1_value.value(),self.serial_1_encoder_2_value.value(),self.serial_1_encoder_3_value.value())
        
    def set_serial_2_pos_fuc(self):
        self.data_send_serial_2(self.serial_2_yaw.value(),self.serial_2_pitch.value(),self.serial_2_roll.value(),self.serial_2_encoder_1_value.value(),self.serial_2_encoder_2_value.value(),self.serial_2_encoder_3_value.value())

    def scan_fuc(self):
        self.current_serial_1_encoder_1  = self.current_serial_1_encoder_1 + 1
        if self.current_serial_1_encoder_1 >=90:
            self.current_serial_1_encoder_1 = 90
        self.serial_1_encoder_1_value.setValue(self.current_serial_1_encoder_1)
        self.set_serial_1_pos_fuc()
        if self.current_power_measurements > self.max_db:
            data = [self.current_power_measurements,self.serial_1_yuntai_yaw,self.serial_1_yuntai_pitch,self.serial_1_yuntai_roll,self.serial_1_encoder_1,self.serial_1_encoder_2,self.serial_1_encoder_3,self.serial_2_encoder_1,self.serial_2_encoder_2,self.serial_2_encoder_3]
            self.data_0 = numpy.array([data])
            if os.path.exists("data.txt"):
                with open('data.txt','w')as f:
                    numpy.savetxt(f, self.data_0, fmt='%s')  
            else:
                numpy.savetxt("data.txt",self.data_0,fmt='%s')
            self.max_db = self.current_power_measurements

    def refresh_ui(self):
         self.message_text.setText("云台航向:"+str(self.serial_1_yuntai_yaw)+" 云台俯仰:"+str(self.serial_1_yuntai_pitch)+" 云台横滚:"+str(self.serial_1_yuntai_roll))
         self.message_text.append("\r\n"+"编码器1:"+str(self.serial_1_encoder_1)+" 编码器2:"+str(self.serial_1_encoder_2)+" 编码器3:"+str(self.serial_1_encoder_3))
         self.message_text.append("\r\n"+"编码器4:"+str(self.serial_2_encoder_1)+" 编码器5:"+str(self.serial_2_encoder_2)+" 编码器6:"+str(self.serial_2_encoder_3))
         self.message_text.append("\r\n"+"光功率:"+str(self.current_power_measurements)+" dB")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = myDialog(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())